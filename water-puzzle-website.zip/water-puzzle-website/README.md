# Water Puzzle Quest Studio Website

A responsive multi-page static website built with pure HTML, CSS and vanilla JavaScript.

## Pages
- `index.html` — Home and Water Puzzle Quest game information
- `aboutus.html` — About the studio
- `contactus.html` — Contact details

## Shared components
- `components/header.html` — shared navigation
- `components/footer.html` — shared footer
- `js/components.js` — loads the shared components on each page

## Before publishing
1. Open `contactus.html`.
2. Replace `YOUR_SUPPORT_EMAIL@example.com` with your real support email.
3. Update the studio name in the header/footer if needed.

## Run locally
Because the header and footer are loaded with JavaScript `fetch()`, open the folder using a local web server (not by double-clicking the HTML file).

For example, with Python installed:
```bash
python -m http.server 8000
```
Then visit `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a new public GitHub repository, for example `water-puzzle-website`.
2. Upload all files and folders from this project to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for the deployment. Your site URL will look like:
   `https://YOUR-GITHUB-USERNAME.github.io/water-puzzle-website/`

Keep the folder structure unchanged so the shared header and footer can load correctly.
